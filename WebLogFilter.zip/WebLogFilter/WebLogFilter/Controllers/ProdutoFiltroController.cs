﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebLogFilter.Models;

namespace WebLogFilter.Controllers
{
    [LogAction]
    public class ProdutoFiltroController : Controller
    {
        // GET: ProdutoFiltro
        public ActionResult Index()
        {

            var lista = new List<Produto>();

            for (int i = 1; i < 21; i++)
            {
                lista.Add(new Produto { Id = i, Nome = string.Concat("Prod - ", i.ToString()) });
            }

            return View(lista);
        }

        // GET: ProdutoFiltro/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ProdutoFiltro/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ProdutoFiltro/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Produto collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProdutoFiltro/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ProdutoFiltro/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Produto collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProdutoFiltro/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ProdutoFiltro/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Produto collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}